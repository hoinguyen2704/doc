/**
 * Application configuration.
 */
package vn.hoidanit.config;
