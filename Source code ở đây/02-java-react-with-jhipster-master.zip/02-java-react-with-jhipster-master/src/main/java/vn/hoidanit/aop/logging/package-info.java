/**
 * Logging aspect.
 */
package vn.hoidanit.aop.logging;
