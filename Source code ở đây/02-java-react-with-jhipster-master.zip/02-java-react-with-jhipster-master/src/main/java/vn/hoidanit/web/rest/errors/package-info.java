/**
 * Rest layer error handling.
 */
package vn.hoidanit.web.rest.errors;
