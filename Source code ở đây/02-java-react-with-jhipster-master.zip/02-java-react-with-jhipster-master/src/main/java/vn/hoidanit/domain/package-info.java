/**
 * Domain objects.
 */
package vn.hoidanit.domain;
