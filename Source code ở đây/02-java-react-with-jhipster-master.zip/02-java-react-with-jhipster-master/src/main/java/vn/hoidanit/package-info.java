/**
 * Application root.
 */
package vn.hoidanit;
