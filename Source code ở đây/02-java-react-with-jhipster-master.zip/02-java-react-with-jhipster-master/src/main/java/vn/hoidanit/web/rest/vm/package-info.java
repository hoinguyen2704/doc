/**
 * Rest layer visual models.
 */
package vn.hoidanit.web.rest.vm;
