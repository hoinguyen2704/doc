/**
 * Rest layer.
 */
package vn.hoidanit.web.rest;
