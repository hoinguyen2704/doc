/**
 * Data transfer objects for rest mapping.
 */
package vn.hoidanit.service.dto;
