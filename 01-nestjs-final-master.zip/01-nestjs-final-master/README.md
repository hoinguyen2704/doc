# Nestjs Typescript (FINAL PROJECT)
Đây là source code final cho series "Nest.JS với TypeScript/MongoDB Siêu Dễ" của tác giả Hỏi Dân IT (Eric)

### Môi trường chạy dự án: Node.js v16.20.0
https://nodejs.org/download/release/v16.20.0/

### Các bước cần làm để chạy dự án NestJS

#### 1. Cài đặt thư viện với câu lệnh: npm i --legacy-peer-dep
#### 2. Chạy dự án với câu lệnh: npm run dev

## Về tác giả
Mọi thông tin về Tác giả Hỏi Dân IT, các bạn có thể tìm kiếm tại đây:

Website chính thức: https://hoidanit.vn/

Youtube “Hỏi Dân IT” : https://www.youtube.com/@hoidanit

Tiktok “Hỏi Dân IT” :  https://www.tiktok.com/@hoidanit

Fanpage “Hỏi Dân IT” : https://www.facebook.com/askITwithERIC/

Udemy Hỏi Dân IT: https://www.udemy.com/user/eric-7039/

